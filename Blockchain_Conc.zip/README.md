Concurrency eindopdracht: Blockchain proof of concept

Made by:

- Daniel Zondervan
- Jos de Vries

Reference:
https://github.com/jonnylynchy/Blockchain-C-Plus-Plus-Example

